import { useContext } from "react";
import { Trash2 } from "lucide-react";
import { CartContext } from "../context/CartContext";
import "../css/CartItem.css";

function CartItem({ item }) {
  const {
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
  } = useContext(CartContext);

  return (
    <div className="cart-item">

      <img
        src={item.image}
        alt={item.name}
      />

      <div className="cart-details">

        <h3>{item.name}</h3>

        <p>{item.category}</p>

        <h4>₹{item.price.toLocaleString()}</h4>

      </div>

      <div className="cart-quantity">

        <button
          onClick={() => decreaseQuantity(item.id)}
        >
          -
        </button>

        <span>{item.quantity}</span>

        <button
          onClick={() => increaseQuantity(item.id)}
        >
          +
        </button>

      </div>

      <div className="cart-subtotal">

        ₹{(item.price * item.quantity).toLocaleString()}

      </div>

      <button
        className="remove-btn"
        onClick={() => removeFromCart(item.id)}
      >
        <Trash2 size={20} />
      </button>

    </div>
  );
}

export default CartItem;