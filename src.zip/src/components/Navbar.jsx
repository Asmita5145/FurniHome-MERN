import { NavLink, Link } from "react-router-dom";
import { ShoppingCart, Search, Heart } from "lucide-react";
import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { WishlistContext } from "../context/WishlistContext";
import logo from "../assets/images/logo/logo.png";
import "../css/Navbar.css";

function Navbar() {
  const { cart } = useContext(CartContext);
  const { wishlist } = useContext(WishlistContext);
  return (
    <nav className="navbar">
      {/* Logo */}
      <Link to="/" className="logo">
        <img src={logo} alt="FurniHome Logo" />
      </Link>

      {/* Navigation */}
      <ul className="nav-links">
        <li>
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            Home
          </NavLink>
        </li>

        <li>
          <NavLink
            to="/shop"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            Shop
          </NavLink>
        </li>

        <li>
          <NavLink
            to="/about"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            About
          </NavLink>
        </li>

        <li>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            Contact
          </NavLink>
        </li>
      </ul>

      {/* Icons */}
      <div className="nav-icons">
        <Search className="icon" />

        <Link to="/wishlist" className="wishlist-icon">
          <Heart className="icon" />

          <span className="cart-count">
            {wishlist.length}
          </span>
        </Link>

        <Link to="/cart" className="cart-icon">
          <ShoppingCart className="icon" />
          <span className="cart-count">
            {cart.reduce((total, item) => total + item.quantity, 0)}
          </span>        
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;

