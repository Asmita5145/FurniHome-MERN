import ProductCard from "./ProductCard";
import products from "../data/products";
import "../css/ProductGrid.css";

function ProductGrid({
  search = "",
  category = "All",
  sortBy = "default",
  maxPrice = 50000,
}) {

  let filteredProducts = products.filter((product) => {

    const matchesSearch =
      product.name
        .toLowerCase()
        .includes(search.toLowerCase());

    const matchesCategory =
      category === "All" ||
      product.category === category;

    const matchesPrice =
      product.price <= maxPrice;

    return (
      matchesSearch &&
      matchesCategory &&
      matchesPrice
    );

  });

  switch (sortBy) {

    case "low":
      filteredProducts.sort((a, b) => a.price - b.price);
      break;

    case "high":
      filteredProducts.sort((a, b) => b.price - a.price);
      break;

    case "rating":
      filteredProducts.sort((a, b) => b.rating - a.rating);
      break;

    case "new":
      filteredProducts.sort((a, b) => b.id - a.id);
      break;

    default:
      break;
  }

  return (
    <section className="products-section">

      <p className="product-count">
        Showing {filteredProducts.length} Products
      </p>

      <div className="products-grid">

        {filteredProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
          />
        ))}

      </div>

    </section>
  );
}

export default ProductGrid;