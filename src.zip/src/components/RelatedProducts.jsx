import ProductCard from "./ProductCard";
import products from "../data/products";
import "../css/RelatedProducts.css";

function RelatedProducts({ product }) {

  const relatedProducts = products
    .filter(
      (item) =>
        item.category === product.category &&
        item.id !== product.id
    )
    .slice(0, 4);

  if (relatedProducts.length === 0) return null;

  return (
    <section className="related-products">

      <h2>You May Also Like</h2>

      <div className="related-grid">

        {relatedProducts.map((item) => (
          <ProductCard
            key={item.id}
            product={item}
          />
        ))}

      </div>

    </section>
  );
}

export default RelatedProducts;