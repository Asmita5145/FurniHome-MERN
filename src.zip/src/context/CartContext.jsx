import toast from "react-hot-toast";
import { createContext, useState, useEffect } from "react";

export const CartContext = createContext();

function CartProvider({ children }) {

  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem("cart");

    return savedCart ? JSON.parse(savedCart) : [];
  });

  useEffect(() => {
    localStorage.setItem(
      "cart",
      JSON.stringify(cart)
    );
  }, [cart]);

function addToCart(product, quantity = 1) {

  const existingProduct = cart.find(
    (item) => item.id === product.id
  );

  if (existingProduct) {

    const updatedCart = cart.map((item) =>
      item.id === product.id
        ? {
            ...item,
            quantity: item.quantity + quantity,
          }
        : item
    );

    setCart(updatedCart);
    toast.success(`${product.name} quantity updated!`);
  } else {

    setCart([
      ...cart,
      {
        ...product,
        quantity: quantity,
      },
    ]);
    toast.success(`${product.name} added to cart!`);

  }
}

  function increaseQuantity(id) {
    setCart(
      cart.map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      )
    );
  }

  function decreaseQuantity(id) {
    setCart(
      cart
        .map((item) =>
          item.id === id
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }

  function removeFromCart(id) {
    setCart(cart.filter((item) => item.id !== id));
    toast.success("Product removed from cart");
  }

  function clearCart() {
    setCart([]);
    toast.success("Cart cleared");
  }

 return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        increaseQuantity,
        decreaseQuantity,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export default CartProvider;


