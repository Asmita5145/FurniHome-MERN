import toast from "react-hot-toast";
import { createContext, useState, useEffect } from "react";

export const WishlistContext = createContext();

function WishlistProvider({ children }) {
    const [wishlist, setWishlist] = useState(() => {

    const savedWishlist =
        localStorage.getItem("wishlist");

    return savedWishlist
        ? JSON.parse(savedWishlist)
        : [];

    });

    useEffect(() => {

    localStorage.setItem(
        "wishlist",
        JSON.stringify(wishlist)
    );

    }, [wishlist]);

  function toggleWishlist(product) {
    const exists = wishlist.find(
      (item) => item.id === product.id
    );

    if (exists) {
      setWishlist(
        wishlist.filter(
          (item) => item.id !== product.id
        )
      );
      toast.success("Removed from Wishlist");
    } else {
      setWishlist([...wishlist, product]);
      toast.success(`${product.name} added to Wishlist`);
    }
  }

  function isWishlisted(id) {
    return wishlist.some(
      (item) => item.id === id
    );
  }

  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        toggleWishlist,
        isWishlisted,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
}

export default WishlistProvider;