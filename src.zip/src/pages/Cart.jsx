import { useContext } from "react";
import { Link } from "react-router-dom";
import { CartContext } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import CartItem from "../components/CartItem";
import "../css/Cart.css";

function Cart() {
  const { cart, clearCart } = useContext(CartContext);

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const totalItems = cart.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  const navigate = useNavigate();

  if (cart.length === 0) {
    return (
      <div className="empty-cart">
        <h1>Your Cart is Empty 🛒</h1>

        <Link to="/shop">
          <button>Continue Shopping</button>
        </Link>
      </div>
    );
  }

  return (
    <section className="cart-page">

      <h1>Shopping Cart</h1>

      {cart.map((item) => (
        <CartItem
          key={item.id}
          item={item}
        />
      ))}

      <div className="cart-summary">

        <h2>
          Total Items : {totalItems}
        </h2>

        <h2>
          Grand Total :
          ₹{total.toLocaleString()}
        </h2>

        <div className="cart-buttons">

          <button
            className="checkout-btn"
            onClick={() => navigate("/checkout")}
          >
            Proceed to Checkout
          </button>

          <button
            className="clear-cart-btn"
            onClick={clearCart}
          >
            Clear Cart
          </button>

        </div>

      </div>

    </section>
  );
}

export default Cart;