import { useState } from "react";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import "../css/Contact.css";

function Contact() {
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Thank you! Your message has been sent successfully.");
  };

  return (
    <div className="contact-page">

      {/* Hero */}

      <section className="contact-hero">
        <h1>Contact Us</h1>

        <p>
          We'd love to hear from you. Get in touch with us anytime.
        </p>
      </section>

      {/* Contact Section */}

      <section className="contact-container">

        {/* Left Side */}

        <div className="contact-info">

          <h2>Get In Touch</h2>

          <p>
            Have questions about our furniture or need assistance?
            Our team is always ready to help.
          </p>

          <div className="info-item">
            <MapPin />
            <div>
              <h4>Address</h4>
              <p>Pune, Maharashtra, India</p>
            </div>
          </div>

          <div className="info-item">
            <Phone />
            <div>
              <h4>Phone</h4>
              <p>+91 98765 43210</p>
            </div>
          </div>

          <div className="info-item">
            <Mail />
            <div>
              <h4>Email</h4>
              <p>support@furnihome.com</p>
            </div>
          </div>

          <div className="info-item">
            <Clock />
            <div>
              <h4>Business Hours</h4>
              <p>Mon - Sat : 9:00 AM - 7:00 PM</p>
            </div>
          </div>

        </div>

        {/* Right Side */}

        <div className="contact-form">

          <h2>Send Message</h2>

          <form onSubmit={handleSubmit}>

            <input
              type="text"
              placeholder="Your Name"
            />

            <input
              type="email"
              placeholder="Your Email"
            />

            <input
              type="text"
              placeholder="Subject"
            />

            <textarea
              rows="6"
              placeholder="Your Message"
            ></textarea>

            <button type="submit">
              Send Message
            </button>

          </form>

        </div>

      </section>

    </div>
  );
}

export default Contact;