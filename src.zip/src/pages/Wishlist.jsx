import { useContext } from "react";
import { Link } from "react-router-dom";
import { WishlistContext } from "../context/WishlistContext";
import WishlistItem from "../components/WishlistItem";
import "../css/Wishlist.css";

function Wishlist() {

  const { wishlist } = useContext(WishlistContext);

  if (wishlist.length === 0) {

    return (

      <div className="empty-wishlist">

        <h1>Your Wishlist is Empty ❤️</h1>

        <Link to="/shop">
          <button>Continue Shopping</button>
        </Link>

      </div>

    );

  }

  return (

    <section className="wishlist-page">

      <h1>My Wishlist</h1>

      {wishlist.map((product) => (

        <WishlistItem
          key={product.id}
          product={product}
        />

      ))}

    </section>

  );

}

export default Wishlist;